# WORKS'2017: Appendix

This notebook was created by Jeremy White as a brief tutorial to introduce FloPy package.

## Notebook
The notebook file is <a href="load.ipynb">load.ipynb</a>.

## Input Files
You can download the input files at: https://figshare.com/s/904c4724a10990d0761f 

Unzip the zip file (hagm_nosub.tar.gz - 143.27 MB) in the same directory of the notebook file. All the input files are inside the folder named <b>hagm_nosub</b>.